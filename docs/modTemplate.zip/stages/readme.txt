Add your stage .json and .lua files here!

"directory" //the directory to load
"defaultZoom" //the default zoom, lol
"isPixelStage" //in the name
"hide_girlfriend" //in the name

"boyfriend" //boyfriend's position
"girlfriend" //girlfriend's position
"opponent" //opponent's position

"camera_boyfriend" //boyfriend's camera offset
"camera_girlfriend" //girlfriend's camera offset
"camera_opponent" //opponent's camera offset

"camera_speed" //the speed of the camera
"camera_move_offset" //how many the camera will move when a character sing
