Put your custom character icons here!
Icons must start with "icon-" or it won't be read!
us this template for your icon
{
    "normal": [
        false, // for animated icons only, loop (if set to false, the anim will be played on beat hit)
        0,	//offset X
        0	//offset Y
    ],
    "lose": [
        false,
        0,
        0
    ],
    "win": [ //delet this part if your icon doesn't have a win icon, for compatibility issue
        false,
        0,
        0
    ]
}